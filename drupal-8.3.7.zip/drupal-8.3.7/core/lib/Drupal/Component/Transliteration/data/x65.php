<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'pan', 'yang', 'lei', 'ca', 'shu', 'zan', 'nian', 'xian', 'jun', 'huo', 'li', 'la', 'huan', 'ying', 'lu', 'long',
  0x10 => 'qian', 'qian', 'zan', 'qian', 'lan', 'xian', 'ying', 'mei', 'rang', 'chan', 'ying', 'cuan', 'xie', 'she', 'luo', 'jun',
  0x20 => 'mi', 'li', 'zan', 'luan', 'tan', 'zuan', 'li', 'dian', 'wa', 'dang', 'jiao', 'jue', 'lan', 'li', 'nang', 'zhi',
  0x30 => 'gui', 'gui', 'qi', 'xun', 'pu', 'sui', 'shou', 'kao', 'you', 'gai', 'yi', 'gong', 'gan', 'ban', 'fang', 'zheng',
  0x40 => 'po', 'dian', 'kou', 'min', 'wu', 'gu', 'he', 'ce', 'xiao', 'mi', 'chu', 'ge', 'di', 'xu', 'jiao', 'min',
  0x50 => 'chen', 'jiu', 'shen', 'duo', 'yu', 'chi', 'ao', 'bai', 'xu', 'jiao', 'duo', 'lian', 'nie', 'bi', 'chang', 'dian',
  0x60 => 'duo', 'yi', 'gan', 'san', 'ke', 'yan', 'dun', 'ji', 'tou', 'xiao', 'duo', 'jiao', 'jing', 'yang', 'xia', 'min',
  0x70 => 'shu', 'ai', 'qiao', 'ai', 'zheng', 'di', 'zhen', 'fu', 'shu', 'liao', 'qu', 'xiong', 'yi', 'jiao', 'shan', 'jiao',
  0x80 => 'zhuo', 'yi', 'lian', 'bi', 'li', 'xiao', 'xiao', 'wen', 'xue', 'qi', 'qi', 'zhai', 'bin', 'jue', 'zhai', 'lang',
  0x90 => 'fei', 'ban', 'ban', 'lan', 'yu', 'lan', 'wei', 'dou', 'sheng', 'liao', 'jia', 'hu', 'xie', 'jia', 'yu', 'zhen',
  0xA0 => 'jiao', 'wo', 'tiao', 'dou', 'jin', 'chi', 'yin', 'fu', 'qiang', 'zhan', 'qu', 'zhuo', 'zhan', 'duan', 'cuo', 'si',
  0xB0 => 'xin', 'zhuo', 'zhuo', 'qin', 'lin', 'zhuo', 'chu', 'duan', 'zhu', 'fang', 'chan', 'hang', 'yu', 'shi', 'pei', 'you',
  0xC0 => 'mei', 'pang', 'qi', 'zhan', 'mao', 'lu', 'pei', 'pi', 'liu', 'fu', 'fang', 'xuan', 'jing', 'jing', 'ni', 'zu',
  0xD0 => 'zhao', 'yi', 'liu', 'shao', 'jian', 'yu', 'yi', 'qi', 'zhi', 'fan', 'piao', 'fan', 'zhan', 'kuai', 'sui', 'yu',
  0xE0 => 'wu', 'ji', 'ji', 'ji', 'huo', 'ri', 'dan', 'jiu', 'zhi', 'zao', 'xie', 'tiao', 'xun', 'xu', 'ga', 'la',
  0xF0 => 'gan', 'han', 'tai', 'di', 'xu', 'chan', 'shi', 'kuang', 'yang', 'shi', 'wang', 'min', 'min', 'tun', 'chun', 'wu',
];
