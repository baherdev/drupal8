<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'zhui', 'zi', 'ke', 'xiang', 'jian', 'mian', 'lan', 'ti', 'miao', 'ji', 'yun', 'hui', 'si', 'duo', 'duan', 'bian',
  0x10 => 'xian', 'gou', 'zhui', 'huan', 'di', 'lu', 'bian', 'min', 'yuan', 'jin', 'fu', 'ru', 'zhen', 'feng', 'cui', 'gao',
  0x20 => 'chan', 'li', 'yi', 'jian', 'bin', 'piao', 'man', 'lei', 'ying', 'suo', 'mou', 'sao', 'xie', 'liao', 'shan', 'zeng',
  0x30 => 'jiang', 'qian', 'qiao', 'huan', 'jiao', 'zuan', 'fou', 'xie', 'gang', 'fou', 'que', 'fou', 'qi', 'bo', 'ping', 'xiang',
  0x40 => 'zhao', 'gang', 'ying', 'ying', 'qing', 'xia', 'guan', 'zun', 'tan', 'cang', 'qi', 'weng', 'ying', 'lei', 'tan', 'lu',
  0x50 => 'guan', 'wang', 'wang', 'gang', 'wang', 'han', 'luo', 'luo', 'fu', 'mi', 'fa', 'gu', 'zhu', 'ju', 'mao', 'gu',
  0x60 => 'min', 'gang', 'ba', 'gua', 'ti', 'juan', 'fu', 'shen', 'yan', 'zhao', 'zui', 'gua', 'zhuo', 'yu', 'zhi', 'an',
  0x70 => 'fa', 'lan', 'shu', 'si', 'pi', 'ma', 'liu', 'ba', 'fa', 'li', 'chao', 'wei', 'bi', 'ji', 'zeng', 'chong',
  0x80 => 'liu', 'ji', 'juan', 'mi', 'zhao', 'luo', 'pi', 'ji', 'ji', 'luan', 'yang', 'mi', 'qiang', 'da', 'mei', 'yang',
  0x90 => 'you', 'you', 'fen', 'ba', 'gao', 'yang', 'gu', 'qiang', 'zang', 'gao', 'ling', 'yi', 'zhu', 'di', 'xiu', 'qiang',
  0xA0 => 'yi', 'xian', 'rong', 'qun', 'qun', 'qiang', 'huan', 'suo', 'xian', 'yi', 'yang', 'qiang', 'qian', 'yu', 'geng', 'jie',
  0xB0 => 'tang', 'yuan', 'xi', 'fan', 'shan', 'fen', 'shan', 'lian', 'lei', 'geng', 'nou', 'qiang', 'chan', 'yu', 'gong', 'yi',
  0xC0 => 'chong', 'weng', 'fen', 'hong', 'chi', 'chi', 'cui', 'fu', 'xia', 'ben', 'yi', 'la', 'yi', 'pi', 'ling', 'liu',
  0xD0 => 'zhi', 'qu', 'xi', 'xie', 'xiang', 'xi', 'xi', 'ke', 'qiao', 'hui', 'hui', 'xiao', 'sha', 'hong', 'jiang', 'di',
  0xE0 => 'cui', 'fei', 'dao', 'sha', 'chi', 'zhu', 'jian', 'xuan', 'chi', 'pian', 'zong', 'wan', 'hui', 'hou', 'he', 'he',
  0xF0 => 'han', 'ao', 'piao', 'yi', 'lian', 'hou', 'ao', 'lin', 'pen', 'qiao', 'ao', 'fan', 'yi', 'hui', 'xuan', 'dao',
];
